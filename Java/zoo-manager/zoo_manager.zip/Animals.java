public abstract class Animals {

    /**
     * all animals have own name and age.
     * the method MealSize is used for all animals.
     */
    protected String name;
    protected int age;
    public abstract double MealSize(double dailyMeal);

}
