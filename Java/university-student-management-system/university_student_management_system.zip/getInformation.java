public interface getInformation {
        /**
         * will be used to get information about both people and academic entities
         * @return string of information
         */
        String getInfo();
}
